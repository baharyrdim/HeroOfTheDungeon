public class Sword extends Weapon {

    public Sword(String name, int weight, int value) {

        super(name, weight, value);

    }

}
