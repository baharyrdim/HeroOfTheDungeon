public class Shield extends Weapon{
    public Shield(String name, int weight, int value) {
        super(name, weight, value);

    }
}


