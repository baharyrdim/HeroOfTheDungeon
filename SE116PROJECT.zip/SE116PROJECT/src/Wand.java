public class Wand extends Weapon{
    public Wand(String name, int weight, int value) {
        super(name, weight, value);

    }
}
