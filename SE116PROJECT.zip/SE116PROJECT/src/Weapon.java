public class Weapon extends Item{
    public Weapon(String name, int weight, int value) {
        super(name, weight, value);
    }

}
